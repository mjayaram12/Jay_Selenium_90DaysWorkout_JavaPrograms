package week3.day4;
/**
 * Swapping two numbers without a third varriable
 * @author saradhasriram
 *
 */
public class SwappingTwoNumbers {

	public static void main(String[] args) {

		int a=10 ;
		int b=5;
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("a:"+a+"b:"+b);

	}

}
